---
name: 🖐 Help request
about: I need help with an issue 😕
title: "Help: "
labels: help wanted
---

### Please fill out this template

<!-- A clear and concise description of what the problem is. Ex. I need help with [...] -->


### Additional context

<!-- Add any other context or screenshots about the feature request here. -->
